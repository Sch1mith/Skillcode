const express = require('express');
const app = express();
const port = 3000;

// Definindo a rota para a página inicial
//app.get('/', (req, res) => {
  //res.send('Olá, mundo! Meu primeiro servidor Node.js!');
//});

app.use(express.static('public'));

// Iniciando o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
